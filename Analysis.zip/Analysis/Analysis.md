Name: Amogh Javali

ID: NN/22/2355

Role: Data Analytics


```python
!pip3 install pandas numpy
```

    Requirement already satisfied: pandas in c:\users\amogh\appdata\local\programs\python\python312\lib\site-packages (2.2.2)
    Requirement already satisfied: numpy in c:\users\amogh\appdata\local\programs\python\python312\lib\site-packages (1.26.4)
    Requirement already satisfied: python-dateutil>=2.8.2 in c:\users\amogh\appdata\local\programs\python\python312\lib\site-packages (from pandas) (2.9.0.post0)
    Requirement already satisfied: pytz>=2020.1 in c:\users\amogh\appdata\local\programs\python\python312\lib\site-packages (from pandas) (2024.1)
    Requirement already satisfied: tzdata>=2022.7 in c:\users\amogh\appdata\local\programs\python\python312\lib\site-packages (from pandas) (2024.1)
    Requirement already satisfied: six>=1.5 in c:\users\amogh\appdata\local\programs\python\python312\lib\site-packages (from python-dateutil>=2.8.2->pandas) (1.16.0)
    

    
    [notice] A new release of pip is available: 24.1.1 -> 25.0.1
    [notice] To update, run: python.exe -m pip install --upgrade pip
    


```python
import pandas as pd
```

Data Reading


```python
df = pd.read_csv("CarPrice_Assignment.csv") 
```

Inspecting Data


```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>car_ID</th>
      <th>symboling</th>
      <th>CarName</th>
      <th>fueltype</th>
      <th>aspiration</th>
      <th>doornumber</th>
      <th>carbody</th>
      <th>drivewheel</th>
      <th>enginelocation</th>
      <th>wheelbase</th>
      <th>...</th>
      <th>enginesize</th>
      <th>fuelsystem</th>
      <th>boreratio</th>
      <th>stroke</th>
      <th>compressionratio</th>
      <th>horsepower</th>
      <th>peakrpm</th>
      <th>citympg</th>
      <th>highwaympg</th>
      <th>price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>3</td>
      <td>alfa-romero giulia</td>
      <td>gas</td>
      <td>std</td>
      <td>two</td>
      <td>convertible</td>
      <td>rwd</td>
      <td>front</td>
      <td>88.6</td>
      <td>...</td>
      <td>130</td>
      <td>mpfi</td>
      <td>3.47</td>
      <td>2.68</td>
      <td>9.0</td>
      <td>111</td>
      <td>5000</td>
      <td>21</td>
      <td>27</td>
      <td>13495.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>3</td>
      <td>alfa-romero stelvio</td>
      <td>gas</td>
      <td>std</td>
      <td>two</td>
      <td>convertible</td>
      <td>rwd</td>
      <td>front</td>
      <td>88.6</td>
      <td>...</td>
      <td>130</td>
      <td>mpfi</td>
      <td>3.47</td>
      <td>2.68</td>
      <td>9.0</td>
      <td>111</td>
      <td>5000</td>
      <td>21</td>
      <td>27</td>
      <td>16500.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>1</td>
      <td>alfa-romero Quadrifoglio</td>
      <td>gas</td>
      <td>std</td>
      <td>two</td>
      <td>hatchback</td>
      <td>rwd</td>
      <td>front</td>
      <td>94.5</td>
      <td>...</td>
      <td>152</td>
      <td>mpfi</td>
      <td>2.68</td>
      <td>3.47</td>
      <td>9.0</td>
      <td>154</td>
      <td>5000</td>
      <td>19</td>
      <td>26</td>
      <td>16500.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>2</td>
      <td>audi 100 ls</td>
      <td>gas</td>
      <td>std</td>
      <td>four</td>
      <td>sedan</td>
      <td>fwd</td>
      <td>front</td>
      <td>99.8</td>
      <td>...</td>
      <td>109</td>
      <td>mpfi</td>
      <td>3.19</td>
      <td>3.40</td>
      <td>10.0</td>
      <td>102</td>
      <td>5500</td>
      <td>24</td>
      <td>30</td>
      <td>13950.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>2</td>
      <td>audi 100ls</td>
      <td>gas</td>
      <td>std</td>
      <td>four</td>
      <td>sedan</td>
      <td>4wd</td>
      <td>front</td>
      <td>99.4</td>
      <td>...</td>
      <td>136</td>
      <td>mpfi</td>
      <td>3.19</td>
      <td>3.40</td>
      <td>8.0</td>
      <td>115</td>
      <td>5500</td>
      <td>18</td>
      <td>22</td>
      <td>17450.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>200</th>
      <td>201</td>
      <td>-1</td>
      <td>volvo 145e (sw)</td>
      <td>gas</td>
      <td>std</td>
      <td>four</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>front</td>
      <td>109.1</td>
      <td>...</td>
      <td>141</td>
      <td>mpfi</td>
      <td>3.78</td>
      <td>3.15</td>
      <td>9.5</td>
      <td>114</td>
      <td>5400</td>
      <td>23</td>
      <td>28</td>
      <td>16845.0</td>
    </tr>
    <tr>
      <th>201</th>
      <td>202</td>
      <td>-1</td>
      <td>volvo 144ea</td>
      <td>gas</td>
      <td>turbo</td>
      <td>four</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>front</td>
      <td>109.1</td>
      <td>...</td>
      <td>141</td>
      <td>mpfi</td>
      <td>3.78</td>
      <td>3.15</td>
      <td>8.7</td>
      <td>160</td>
      <td>5300</td>
      <td>19</td>
      <td>25</td>
      <td>19045.0</td>
    </tr>
    <tr>
      <th>202</th>
      <td>203</td>
      <td>-1</td>
      <td>volvo 244dl</td>
      <td>gas</td>
      <td>std</td>
      <td>four</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>front</td>
      <td>109.1</td>
      <td>...</td>
      <td>173</td>
      <td>mpfi</td>
      <td>3.58</td>
      <td>2.87</td>
      <td>8.8</td>
      <td>134</td>
      <td>5500</td>
      <td>18</td>
      <td>23</td>
      <td>21485.0</td>
    </tr>
    <tr>
      <th>203</th>
      <td>204</td>
      <td>-1</td>
      <td>volvo 246</td>
      <td>diesel</td>
      <td>turbo</td>
      <td>four</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>front</td>
      <td>109.1</td>
      <td>...</td>
      <td>145</td>
      <td>idi</td>
      <td>3.01</td>
      <td>3.40</td>
      <td>23.0</td>
      <td>106</td>
      <td>4800</td>
      <td>26</td>
      <td>27</td>
      <td>22470.0</td>
    </tr>
    <tr>
      <th>204</th>
      <td>205</td>
      <td>-1</td>
      <td>volvo 264gl</td>
      <td>gas</td>
      <td>turbo</td>
      <td>four</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>front</td>
      <td>109.1</td>
      <td>...</td>
      <td>141</td>
      <td>mpfi</td>
      <td>3.78</td>
      <td>3.15</td>
      <td>9.5</td>
      <td>114</td>
      <td>5400</td>
      <td>19</td>
      <td>25</td>
      <td>22625.0</td>
    </tr>
  </tbody>
</table>
<p>205 rows × 26 columns</p>
</div>




```python
df.head() 
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>car_ID</th>
      <th>symboling</th>
      <th>CarName</th>
      <th>fueltype</th>
      <th>aspiration</th>
      <th>doornumber</th>
      <th>carbody</th>
      <th>drivewheel</th>
      <th>enginelocation</th>
      <th>wheelbase</th>
      <th>...</th>
      <th>enginesize</th>
      <th>fuelsystem</th>
      <th>boreratio</th>
      <th>stroke</th>
      <th>compressionratio</th>
      <th>horsepower</th>
      <th>peakrpm</th>
      <th>citympg</th>
      <th>highwaympg</th>
      <th>price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>3</td>
      <td>alfa-romero giulia</td>
      <td>gas</td>
      <td>std</td>
      <td>two</td>
      <td>convertible</td>
      <td>rwd</td>
      <td>front</td>
      <td>88.6</td>
      <td>...</td>
      <td>130</td>
      <td>mpfi</td>
      <td>3.47</td>
      <td>2.68</td>
      <td>9.0</td>
      <td>111</td>
      <td>5000</td>
      <td>21</td>
      <td>27</td>
      <td>13495.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>3</td>
      <td>alfa-romero stelvio</td>
      <td>gas</td>
      <td>std</td>
      <td>two</td>
      <td>convertible</td>
      <td>rwd</td>
      <td>front</td>
      <td>88.6</td>
      <td>...</td>
      <td>130</td>
      <td>mpfi</td>
      <td>3.47</td>
      <td>2.68</td>
      <td>9.0</td>
      <td>111</td>
      <td>5000</td>
      <td>21</td>
      <td>27</td>
      <td>16500.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>1</td>
      <td>alfa-romero Quadrifoglio</td>
      <td>gas</td>
      <td>std</td>
      <td>two</td>
      <td>hatchback</td>
      <td>rwd</td>
      <td>front</td>
      <td>94.5</td>
      <td>...</td>
      <td>152</td>
      <td>mpfi</td>
      <td>2.68</td>
      <td>3.47</td>
      <td>9.0</td>
      <td>154</td>
      <td>5000</td>
      <td>19</td>
      <td>26</td>
      <td>16500.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>2</td>
      <td>audi 100 ls</td>
      <td>gas</td>
      <td>std</td>
      <td>four</td>
      <td>sedan</td>
      <td>fwd</td>
      <td>front</td>
      <td>99.8</td>
      <td>...</td>
      <td>109</td>
      <td>mpfi</td>
      <td>3.19</td>
      <td>3.40</td>
      <td>10.0</td>
      <td>102</td>
      <td>5500</td>
      <td>24</td>
      <td>30</td>
      <td>13950.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>2</td>
      <td>audi 100ls</td>
      <td>gas</td>
      <td>std</td>
      <td>four</td>
      <td>sedan</td>
      <td>4wd</td>
      <td>front</td>
      <td>99.4</td>
      <td>...</td>
      <td>136</td>
      <td>mpfi</td>
      <td>3.19</td>
      <td>3.40</td>
      <td>8.0</td>
      <td>115</td>
      <td>5500</td>
      <td>18</td>
      <td>22</td>
      <td>17450.0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 26 columns</p>
</div>




```python
df.info() 
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 205 entries, 0 to 204
    Data columns (total 26 columns):
     #   Column            Non-Null Count  Dtype  
    ---  ------            --------------  -----  
     0   car_ID            205 non-null    int64  
     1   symboling         205 non-null    int64  
     2   CarName           205 non-null    object 
     3   fueltype          205 non-null    object 
     4   aspiration        205 non-null    object 
     5   doornumber        205 non-null    object 
     6   carbody           205 non-null    object 
     7   drivewheel        205 non-null    object 
     8   enginelocation    205 non-null    object 
     9   wheelbase         205 non-null    float64
     10  carlength         205 non-null    float64
     11  carwidth          205 non-null    float64
     12  carheight         205 non-null    float64
     13  curbweight        205 non-null    int64  
     14  enginetype        205 non-null    object 
     15  cylindernumber    205 non-null    object 
     16  enginesize        205 non-null    int64  
     17  fuelsystem        205 non-null    object 
     18  boreratio         205 non-null    float64
     19  stroke            205 non-null    float64
     20  compressionratio  205 non-null    float64
     21  horsepower        205 non-null    int64  
     22  peakrpm           205 non-null    int64  
     23  citympg           205 non-null    int64  
     24  highwaympg        205 non-null    int64  
     25  price             205 non-null    float64
    dtypes: float64(8), int64(8), object(10)
    memory usage: 41.8+ KB
    


```python
df.describe() 
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>car_ID</th>
      <th>symboling</th>
      <th>wheelbase</th>
      <th>carlength</th>
      <th>carwidth</th>
      <th>carheight</th>
      <th>curbweight</th>
      <th>enginesize</th>
      <th>boreratio</th>
      <th>stroke</th>
      <th>compressionratio</th>
      <th>horsepower</th>
      <th>peakrpm</th>
      <th>citympg</th>
      <th>highwaympg</th>
      <th>price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>205.000000</td>
      <td>205.000000</td>
      <td>205.000000</td>
      <td>205.000000</td>
      <td>205.000000</td>
      <td>205.000000</td>
      <td>205.000000</td>
      <td>205.000000</td>
      <td>205.000000</td>
      <td>205.000000</td>
      <td>205.000000</td>
      <td>205.000000</td>
      <td>205.000000</td>
      <td>205.000000</td>
      <td>205.000000</td>
      <td>205.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>103.000000</td>
      <td>0.834146</td>
      <td>98.756585</td>
      <td>174.049268</td>
      <td>65.907805</td>
      <td>53.724878</td>
      <td>2555.565854</td>
      <td>126.907317</td>
      <td>3.329756</td>
      <td>3.255415</td>
      <td>10.142537</td>
      <td>104.117073</td>
      <td>5125.121951</td>
      <td>25.219512</td>
      <td>30.751220</td>
      <td>13276.710571</td>
    </tr>
    <tr>
      <th>std</th>
      <td>59.322565</td>
      <td>1.245307</td>
      <td>6.021776</td>
      <td>12.337289</td>
      <td>2.145204</td>
      <td>2.443522</td>
      <td>520.680204</td>
      <td>41.642693</td>
      <td>0.270844</td>
      <td>0.313597</td>
      <td>3.972040</td>
      <td>39.544167</td>
      <td>476.985643</td>
      <td>6.542142</td>
      <td>6.886443</td>
      <td>7988.852332</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>-2.000000</td>
      <td>86.600000</td>
      <td>141.100000</td>
      <td>60.300000</td>
      <td>47.800000</td>
      <td>1488.000000</td>
      <td>61.000000</td>
      <td>2.540000</td>
      <td>2.070000</td>
      <td>7.000000</td>
      <td>48.000000</td>
      <td>4150.000000</td>
      <td>13.000000</td>
      <td>16.000000</td>
      <td>5118.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>52.000000</td>
      <td>0.000000</td>
      <td>94.500000</td>
      <td>166.300000</td>
      <td>64.100000</td>
      <td>52.000000</td>
      <td>2145.000000</td>
      <td>97.000000</td>
      <td>3.150000</td>
      <td>3.110000</td>
      <td>8.600000</td>
      <td>70.000000</td>
      <td>4800.000000</td>
      <td>19.000000</td>
      <td>25.000000</td>
      <td>7788.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>103.000000</td>
      <td>1.000000</td>
      <td>97.000000</td>
      <td>173.200000</td>
      <td>65.500000</td>
      <td>54.100000</td>
      <td>2414.000000</td>
      <td>120.000000</td>
      <td>3.310000</td>
      <td>3.290000</td>
      <td>9.000000</td>
      <td>95.000000</td>
      <td>5200.000000</td>
      <td>24.000000</td>
      <td>30.000000</td>
      <td>10295.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>154.000000</td>
      <td>2.000000</td>
      <td>102.400000</td>
      <td>183.100000</td>
      <td>66.900000</td>
      <td>55.500000</td>
      <td>2935.000000</td>
      <td>141.000000</td>
      <td>3.580000</td>
      <td>3.410000</td>
      <td>9.400000</td>
      <td>116.000000</td>
      <td>5500.000000</td>
      <td>30.000000</td>
      <td>34.000000</td>
      <td>16503.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>205.000000</td>
      <td>3.000000</td>
      <td>120.900000</td>
      <td>208.100000</td>
      <td>72.300000</td>
      <td>59.800000</td>
      <td>4066.000000</td>
      <td>326.000000</td>
      <td>3.940000</td>
      <td>4.170000</td>
      <td>23.000000</td>
      <td>288.000000</td>
      <td>6600.000000</td>
      <td>49.000000</td>
      <td>54.000000</td>
      <td>45400.000000</td>
    </tr>
  </tbody>
</table>
</div>



Data Cleaning

Checking for null values and Percentage


```python
df.isnull()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>car_ID</th>
      <th>symboling</th>
      <th>CarName</th>
      <th>fueltype</th>
      <th>aspiration</th>
      <th>doornumber</th>
      <th>carbody</th>
      <th>drivewheel</th>
      <th>enginelocation</th>
      <th>wheelbase</th>
      <th>...</th>
      <th>enginesize</th>
      <th>fuelsystem</th>
      <th>boreratio</th>
      <th>stroke</th>
      <th>compressionratio</th>
      <th>horsepower</th>
      <th>peakrpm</th>
      <th>citympg</th>
      <th>highwaympg</th>
      <th>price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>1</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>3</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>4</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>200</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>201</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>202</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>203</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>204</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
<p>205 rows × 26 columns</p>
</div>




```python
null_counts = df.isnull().sum()
```


```python
null_counts
```




    car_ID              0
    symboling           0
    CarName             0
    fueltype            0
    aspiration          0
    doornumber          0
    carbody             0
    drivewheel          0
    enginelocation      0
    wheelbase           0
    carlength           0
    carwidth            0
    carheight           0
    curbweight          0
    enginetype          0
    cylindernumber      0
    enginesize          0
    fuelsystem          0
    boreratio           0
    stroke              0
    compressionratio    0
    horsepower          0
    peakrpm             0
    citympg             0
    highwaympg          0
    price               0
    dtype: int64




```python
null_percentage = (df.isnull().sum() / len(df)) * 100
```


```python
null_percentage
```




    car_ID              0.0
    symboling           0.0
    CarName             0.0
    fueltype            0.0
    aspiration          0.0
    doornumber          0.0
    carbody             0.0
    drivewheel          0.0
    enginelocation      0.0
    wheelbase           0.0
    carlength           0.0
    carwidth            0.0
    carheight           0.0
    curbweight          0.0
    enginetype          0.0
    cylindernumber      0.0
    enginesize          0.0
    fuelsystem          0.0
    boreratio           0.0
    stroke              0.0
    compressionratio    0.0
    horsepower          0.0
    peakrpm             0.0
    citympg             0.0
    highwaympg          0.0
    price               0.0
    dtype: float64




```python
null_df = pd.DataFrame({'Null Count': null_counts, 'Null Percentage': null_percentage})
```


```python
null_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Null Count</th>
      <th>Null Percentage</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>car_ID</th>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>symboling</th>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>CarName</th>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>fueltype</th>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>aspiration</th>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>doornumber</th>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>carbody</th>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>drivewheel</th>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>enginelocation</th>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>wheelbase</th>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>carlength</th>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>carwidth</th>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>carheight</th>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>curbweight</th>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>enginetype</th>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>cylindernumber</th>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>enginesize</th>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>fuelsystem</th>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>boreratio</th>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>stroke</th>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>compressionratio</th>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>horsepower</th>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>peakrpm</th>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>citympg</th>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>highwaympg</th>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>price</th>
      <td>0</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
null_df = null_df[null_df['Null Count'] > 0]
```


```python
null_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Null Count</th>
      <th>Null Percentage</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
</table>
</div>




```python
print(null_df)
```

    Empty DataFrame
    Columns: [Null Count, Null Percentage]
    Index: []
    


```python
threshold = 40
```


```python
columns_to_drop = null_df[null_df['Null Percentage'] > threshold].index
```


```python
df.drop(columns=columns_to_drop, axis=1, inplace=True)
```


```python
print(f"Dropped columns: {columns_to_drop}")
```

    Dropped columns: Index([], dtype='object')
    


```python
columns_to_drop
```




    Index([], dtype='object')




```python
df.dropna(thresh=df.shape[1] * 0.5, inplace=True)
```


```python
print(df.dropna(thresh=df.shape[1] * 0.5, inplace=True))
```

    None
    

Dropping 'enginelocation' Column as all cars engine location is Front only 


```python
df.drop(columns=['enginelocation'], axis=1, inplace=True)
```


```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>car_ID</th>
      <th>symboling</th>
      <th>CarName</th>
      <th>fueltype</th>
      <th>aspiration</th>
      <th>doornumber</th>
      <th>carbody</th>
      <th>drivewheel</th>
      <th>wheelbase</th>
      <th>carlength</th>
      <th>...</th>
      <th>enginesize</th>
      <th>fuelsystem</th>
      <th>boreratio</th>
      <th>stroke</th>
      <th>compressionratio</th>
      <th>horsepower</th>
      <th>peakrpm</th>
      <th>citympg</th>
      <th>highwaympg</th>
      <th>price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>3</td>
      <td>alfa-romero giulia</td>
      <td>gas</td>
      <td>std</td>
      <td>two</td>
      <td>convertible</td>
      <td>rwd</td>
      <td>88.6</td>
      <td>168.8</td>
      <td>...</td>
      <td>130</td>
      <td>mpfi</td>
      <td>3.47</td>
      <td>2.68</td>
      <td>9.0</td>
      <td>111</td>
      <td>5000</td>
      <td>21</td>
      <td>27</td>
      <td>13495.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>3</td>
      <td>alfa-romero stelvio</td>
      <td>gas</td>
      <td>std</td>
      <td>two</td>
      <td>convertible</td>
      <td>rwd</td>
      <td>88.6</td>
      <td>168.8</td>
      <td>...</td>
      <td>130</td>
      <td>mpfi</td>
      <td>3.47</td>
      <td>2.68</td>
      <td>9.0</td>
      <td>111</td>
      <td>5000</td>
      <td>21</td>
      <td>27</td>
      <td>16500.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>1</td>
      <td>alfa-romero Quadrifoglio</td>
      <td>gas</td>
      <td>std</td>
      <td>two</td>
      <td>hatchback</td>
      <td>rwd</td>
      <td>94.5</td>
      <td>171.2</td>
      <td>...</td>
      <td>152</td>
      <td>mpfi</td>
      <td>2.68</td>
      <td>3.47</td>
      <td>9.0</td>
      <td>154</td>
      <td>5000</td>
      <td>19</td>
      <td>26</td>
      <td>16500.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>2</td>
      <td>audi 100 ls</td>
      <td>gas</td>
      <td>std</td>
      <td>four</td>
      <td>sedan</td>
      <td>fwd</td>
      <td>99.8</td>
      <td>176.6</td>
      <td>...</td>
      <td>109</td>
      <td>mpfi</td>
      <td>3.19</td>
      <td>3.40</td>
      <td>10.0</td>
      <td>102</td>
      <td>5500</td>
      <td>24</td>
      <td>30</td>
      <td>13950.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>2</td>
      <td>audi 100ls</td>
      <td>gas</td>
      <td>std</td>
      <td>four</td>
      <td>sedan</td>
      <td>4wd</td>
      <td>99.4</td>
      <td>176.6</td>
      <td>...</td>
      <td>136</td>
      <td>mpfi</td>
      <td>3.19</td>
      <td>3.40</td>
      <td>8.0</td>
      <td>115</td>
      <td>5500</td>
      <td>18</td>
      <td>22</td>
      <td>17450.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>200</th>
      <td>201</td>
      <td>-1</td>
      <td>volvo 145e (sw)</td>
      <td>gas</td>
      <td>std</td>
      <td>four</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>109.1</td>
      <td>188.8</td>
      <td>...</td>
      <td>141</td>
      <td>mpfi</td>
      <td>3.78</td>
      <td>3.15</td>
      <td>9.5</td>
      <td>114</td>
      <td>5400</td>
      <td>23</td>
      <td>28</td>
      <td>16845.0</td>
    </tr>
    <tr>
      <th>201</th>
      <td>202</td>
      <td>-1</td>
      <td>volvo 144ea</td>
      <td>gas</td>
      <td>turbo</td>
      <td>four</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>109.1</td>
      <td>188.8</td>
      <td>...</td>
      <td>141</td>
      <td>mpfi</td>
      <td>3.78</td>
      <td>3.15</td>
      <td>8.7</td>
      <td>160</td>
      <td>5300</td>
      <td>19</td>
      <td>25</td>
      <td>19045.0</td>
    </tr>
    <tr>
      <th>202</th>
      <td>203</td>
      <td>-1</td>
      <td>volvo 244dl</td>
      <td>gas</td>
      <td>std</td>
      <td>four</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>109.1</td>
      <td>188.8</td>
      <td>...</td>
      <td>173</td>
      <td>mpfi</td>
      <td>3.58</td>
      <td>2.87</td>
      <td>8.8</td>
      <td>134</td>
      <td>5500</td>
      <td>18</td>
      <td>23</td>
      <td>21485.0</td>
    </tr>
    <tr>
      <th>203</th>
      <td>204</td>
      <td>-1</td>
      <td>volvo 246</td>
      <td>diesel</td>
      <td>turbo</td>
      <td>four</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>109.1</td>
      <td>188.8</td>
      <td>...</td>
      <td>145</td>
      <td>idi</td>
      <td>3.01</td>
      <td>3.40</td>
      <td>23.0</td>
      <td>106</td>
      <td>4800</td>
      <td>26</td>
      <td>27</td>
      <td>22470.0</td>
    </tr>
    <tr>
      <th>204</th>
      <td>205</td>
      <td>-1</td>
      <td>volvo 264gl</td>
      <td>gas</td>
      <td>turbo</td>
      <td>four</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>109.1</td>
      <td>188.8</td>
      <td>...</td>
      <td>141</td>
      <td>mpfi</td>
      <td>3.78</td>
      <td>3.15</td>
      <td>9.5</td>
      <td>114</td>
      <td>5400</td>
      <td>19</td>
      <td>25</td>
      <td>22625.0</td>
    </tr>
  </tbody>
</table>
<p>205 rows × 25 columns</p>
</div>




```python
import seaborn as sns
import matplotlib.pyplot as plt

df['doornumber'] = df['doornumber'].map({'two': 2, 'four': 4})

plt.figure(figsize=(10,6))
sns.heatmap(df.corr(), annot=True, cmap="coolwarm")
plt.title("Feature Correlation Heatmap")
plt.show()
```


    ---------------------------------------------------------------------------

    ValueError                                Traceback (most recent call last)

    Cell In[27], line 7
          4 df['doornumber'] = df['doornumber'].map({'two': 2, 'four': 4})
          6 plt.figure(figsize=(10,6))
    ----> 7 sns.heatmap(df.corr(), annot=True, cmap="coolwarm")
          8 plt.title("Feature Correlation Heatmap")
          9 plt.show()
    

    File ~\AppData\Local\Programs\Python\Python312\Lib\site-packages\pandas\core\frame.py:11049, in DataFrame.corr(self, method, min_periods, numeric_only)
      11047 cols = data.columns
      11048 idx = cols.copy()
    > 11049 mat = data.to_numpy(dtype=float, na_value=np.nan, copy=False)
      11051 if method == "pearson":
      11052     correl = libalgos.nancorr(mat, minp=min_periods)
    

    File ~\AppData\Local\Programs\Python\Python312\Lib\site-packages\pandas\core\frame.py:1993, in DataFrame.to_numpy(self, dtype, copy, na_value)
       1991 if dtype is not None:
       1992     dtype = np.dtype(dtype)
    -> 1993 result = self._mgr.as_array(dtype=dtype, copy=copy, na_value=na_value)
       1994 if result.dtype is not dtype:
       1995     result = np.asarray(result, dtype=dtype)
    

    File ~\AppData\Local\Programs\Python\Python312\Lib\site-packages\pandas\core\internals\managers.py:1694, in BlockManager.as_array(self, dtype, copy, na_value)
       1692         arr.flags.writeable = False
       1693 else:
    -> 1694     arr = self._interleave(dtype=dtype, na_value=na_value)
       1695     # The underlying data was copied within _interleave, so no need
       1696     # to further copy if copy=True or setting na_value
       1698 if na_value is lib.no_default:
    

    File ~\AppData\Local\Programs\Python\Python312\Lib\site-packages\pandas\core\internals\managers.py:1753, in BlockManager._interleave(self, dtype, na_value)
       1751     else:
       1752         arr = blk.get_values(dtype)
    -> 1753     result[rl.indexer] = arr
       1754     itemmask[rl.indexer] = 1
       1756 if not itemmask.all():
    

    ValueError: could not convert string to float: 'alfa-romero giulia'



    <Figure size 1000x600 with 0 Axes>



```python
print(df.dtypes)
```


```python
import seaborn as sns
import matplotlib.pyplot as plt

df_numeric = df.select_dtypes(include=['number'])

plt.figure(figsize=(10,6))
sns.heatmap(df_numeric.corr(), annot=True, cmap="coolwarm")
plt.title("Feature Correlation Heatmap")
plt.show()
```

Dropping Column 'doornumber' because we can see corelation between 'price' and 'doornumber' is '0.032' which is very low.


```python
df.drop(columns=['doornumber'], axis=1, inplace=True)
```


```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>car_ID</th>
      <th>symboling</th>
      <th>CarName</th>
      <th>fueltype</th>
      <th>aspiration</th>
      <th>carbody</th>
      <th>drivewheel</th>
      <th>wheelbase</th>
      <th>carlength</th>
      <th>carwidth</th>
      <th>...</th>
      <th>enginesize</th>
      <th>fuelsystem</th>
      <th>boreratio</th>
      <th>stroke</th>
      <th>compressionratio</th>
      <th>horsepower</th>
      <th>peakrpm</th>
      <th>citympg</th>
      <th>highwaympg</th>
      <th>price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>3</td>
      <td>alfa-romero giulia</td>
      <td>gas</td>
      <td>std</td>
      <td>convertible</td>
      <td>rwd</td>
      <td>88.6</td>
      <td>168.8</td>
      <td>64.1</td>
      <td>...</td>
      <td>130</td>
      <td>mpfi</td>
      <td>3.47</td>
      <td>2.68</td>
      <td>9.0</td>
      <td>111</td>
      <td>5000</td>
      <td>21</td>
      <td>27</td>
      <td>13495.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>3</td>
      <td>alfa-romero stelvio</td>
      <td>gas</td>
      <td>std</td>
      <td>convertible</td>
      <td>rwd</td>
      <td>88.6</td>
      <td>168.8</td>
      <td>64.1</td>
      <td>...</td>
      <td>130</td>
      <td>mpfi</td>
      <td>3.47</td>
      <td>2.68</td>
      <td>9.0</td>
      <td>111</td>
      <td>5000</td>
      <td>21</td>
      <td>27</td>
      <td>16500.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>1</td>
      <td>alfa-romero Quadrifoglio</td>
      <td>gas</td>
      <td>std</td>
      <td>hatchback</td>
      <td>rwd</td>
      <td>94.5</td>
      <td>171.2</td>
      <td>65.5</td>
      <td>...</td>
      <td>152</td>
      <td>mpfi</td>
      <td>2.68</td>
      <td>3.47</td>
      <td>9.0</td>
      <td>154</td>
      <td>5000</td>
      <td>19</td>
      <td>26</td>
      <td>16500.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>2</td>
      <td>audi 100 ls</td>
      <td>gas</td>
      <td>std</td>
      <td>sedan</td>
      <td>fwd</td>
      <td>99.8</td>
      <td>176.6</td>
      <td>66.2</td>
      <td>...</td>
      <td>109</td>
      <td>mpfi</td>
      <td>3.19</td>
      <td>3.40</td>
      <td>10.0</td>
      <td>102</td>
      <td>5500</td>
      <td>24</td>
      <td>30</td>
      <td>13950.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>2</td>
      <td>audi 100ls</td>
      <td>gas</td>
      <td>std</td>
      <td>sedan</td>
      <td>4wd</td>
      <td>99.4</td>
      <td>176.6</td>
      <td>66.4</td>
      <td>...</td>
      <td>136</td>
      <td>mpfi</td>
      <td>3.19</td>
      <td>3.40</td>
      <td>8.0</td>
      <td>115</td>
      <td>5500</td>
      <td>18</td>
      <td>22</td>
      <td>17450.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>200</th>
      <td>201</td>
      <td>-1</td>
      <td>volvo 145e (sw)</td>
      <td>gas</td>
      <td>std</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>109.1</td>
      <td>188.8</td>
      <td>68.9</td>
      <td>...</td>
      <td>141</td>
      <td>mpfi</td>
      <td>3.78</td>
      <td>3.15</td>
      <td>9.5</td>
      <td>114</td>
      <td>5400</td>
      <td>23</td>
      <td>28</td>
      <td>16845.0</td>
    </tr>
    <tr>
      <th>201</th>
      <td>202</td>
      <td>-1</td>
      <td>volvo 144ea</td>
      <td>gas</td>
      <td>turbo</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>109.1</td>
      <td>188.8</td>
      <td>68.8</td>
      <td>...</td>
      <td>141</td>
      <td>mpfi</td>
      <td>3.78</td>
      <td>3.15</td>
      <td>8.7</td>
      <td>160</td>
      <td>5300</td>
      <td>19</td>
      <td>25</td>
      <td>19045.0</td>
    </tr>
    <tr>
      <th>202</th>
      <td>203</td>
      <td>-1</td>
      <td>volvo 244dl</td>
      <td>gas</td>
      <td>std</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>109.1</td>
      <td>188.8</td>
      <td>68.9</td>
      <td>...</td>
      <td>173</td>
      <td>mpfi</td>
      <td>3.58</td>
      <td>2.87</td>
      <td>8.8</td>
      <td>134</td>
      <td>5500</td>
      <td>18</td>
      <td>23</td>
      <td>21485.0</td>
    </tr>
    <tr>
      <th>203</th>
      <td>204</td>
      <td>-1</td>
      <td>volvo 246</td>
      <td>diesel</td>
      <td>turbo</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>109.1</td>
      <td>188.8</td>
      <td>68.9</td>
      <td>...</td>
      <td>145</td>
      <td>idi</td>
      <td>3.01</td>
      <td>3.40</td>
      <td>23.0</td>
      <td>106</td>
      <td>4800</td>
      <td>26</td>
      <td>27</td>
      <td>22470.0</td>
    </tr>
    <tr>
      <th>204</th>
      <td>205</td>
      <td>-1</td>
      <td>volvo 264gl</td>
      <td>gas</td>
      <td>turbo</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>109.1</td>
      <td>188.8</td>
      <td>68.9</td>
      <td>...</td>
      <td>141</td>
      <td>mpfi</td>
      <td>3.78</td>
      <td>3.15</td>
      <td>9.5</td>
      <td>114</td>
      <td>5400</td>
      <td>19</td>
      <td>25</td>
      <td>22625.0</td>
    </tr>
  </tbody>
</table>
<p>205 rows × 24 columns</p>
</div>




```python
print(df['fueltype'].unique()) 
```

    ['gas' 'diesel']
    

converting char 'gas' and 'diesel' into numeric '0' and '1' to check correlation


```python
df['fueltype'] = df['fueltype'].map({'gas': 0, 'diesel': 1}) 
```


```python
import seaborn as sns
import matplotlib.pyplot as plt

df_numeric = df.select_dtypes(include=['number'])

plt.figure(figsize=(10,6))
sns.heatmap(df_numeric.corr(), annot=True, cmap="coolwarm")
plt.title("Feature Correlation Heatmap")
plt.show()

```


    
![png](output_43_0.png)
    


Dropping 'fueltype' as it is not useful


```python
df.drop(columns=['fueltype'], axis=1, inplace=True)
```


```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>car_ID</th>
      <th>symboling</th>
      <th>CarName</th>
      <th>aspiration</th>
      <th>carbody</th>
      <th>drivewheel</th>
      <th>wheelbase</th>
      <th>carlength</th>
      <th>carwidth</th>
      <th>carheight</th>
      <th>...</th>
      <th>enginesize</th>
      <th>fuelsystem</th>
      <th>boreratio</th>
      <th>stroke</th>
      <th>compressionratio</th>
      <th>horsepower</th>
      <th>peakrpm</th>
      <th>citympg</th>
      <th>highwaympg</th>
      <th>price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>3</td>
      <td>alfa-romero giulia</td>
      <td>std</td>
      <td>convertible</td>
      <td>rwd</td>
      <td>88.6</td>
      <td>168.8</td>
      <td>64.1</td>
      <td>48.8</td>
      <td>...</td>
      <td>130</td>
      <td>mpfi</td>
      <td>3.47</td>
      <td>2.68</td>
      <td>9.0</td>
      <td>111</td>
      <td>5000</td>
      <td>21</td>
      <td>27</td>
      <td>13495.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>3</td>
      <td>alfa-romero stelvio</td>
      <td>std</td>
      <td>convertible</td>
      <td>rwd</td>
      <td>88.6</td>
      <td>168.8</td>
      <td>64.1</td>
      <td>48.8</td>
      <td>...</td>
      <td>130</td>
      <td>mpfi</td>
      <td>3.47</td>
      <td>2.68</td>
      <td>9.0</td>
      <td>111</td>
      <td>5000</td>
      <td>21</td>
      <td>27</td>
      <td>16500.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>1</td>
      <td>alfa-romero Quadrifoglio</td>
      <td>std</td>
      <td>hatchback</td>
      <td>rwd</td>
      <td>94.5</td>
      <td>171.2</td>
      <td>65.5</td>
      <td>52.4</td>
      <td>...</td>
      <td>152</td>
      <td>mpfi</td>
      <td>2.68</td>
      <td>3.47</td>
      <td>9.0</td>
      <td>154</td>
      <td>5000</td>
      <td>19</td>
      <td>26</td>
      <td>16500.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>2</td>
      <td>audi 100 ls</td>
      <td>std</td>
      <td>sedan</td>
      <td>fwd</td>
      <td>99.8</td>
      <td>176.6</td>
      <td>66.2</td>
      <td>54.3</td>
      <td>...</td>
      <td>109</td>
      <td>mpfi</td>
      <td>3.19</td>
      <td>3.40</td>
      <td>10.0</td>
      <td>102</td>
      <td>5500</td>
      <td>24</td>
      <td>30</td>
      <td>13950.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>2</td>
      <td>audi 100ls</td>
      <td>std</td>
      <td>sedan</td>
      <td>4wd</td>
      <td>99.4</td>
      <td>176.6</td>
      <td>66.4</td>
      <td>54.3</td>
      <td>...</td>
      <td>136</td>
      <td>mpfi</td>
      <td>3.19</td>
      <td>3.40</td>
      <td>8.0</td>
      <td>115</td>
      <td>5500</td>
      <td>18</td>
      <td>22</td>
      <td>17450.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>200</th>
      <td>201</td>
      <td>-1</td>
      <td>volvo 145e (sw)</td>
      <td>std</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>109.1</td>
      <td>188.8</td>
      <td>68.9</td>
      <td>55.5</td>
      <td>...</td>
      <td>141</td>
      <td>mpfi</td>
      <td>3.78</td>
      <td>3.15</td>
      <td>9.5</td>
      <td>114</td>
      <td>5400</td>
      <td>23</td>
      <td>28</td>
      <td>16845.0</td>
    </tr>
    <tr>
      <th>201</th>
      <td>202</td>
      <td>-1</td>
      <td>volvo 144ea</td>
      <td>turbo</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>109.1</td>
      <td>188.8</td>
      <td>68.8</td>
      <td>55.5</td>
      <td>...</td>
      <td>141</td>
      <td>mpfi</td>
      <td>3.78</td>
      <td>3.15</td>
      <td>8.7</td>
      <td>160</td>
      <td>5300</td>
      <td>19</td>
      <td>25</td>
      <td>19045.0</td>
    </tr>
    <tr>
      <th>202</th>
      <td>203</td>
      <td>-1</td>
      <td>volvo 244dl</td>
      <td>std</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>109.1</td>
      <td>188.8</td>
      <td>68.9</td>
      <td>55.5</td>
      <td>...</td>
      <td>173</td>
      <td>mpfi</td>
      <td>3.58</td>
      <td>2.87</td>
      <td>8.8</td>
      <td>134</td>
      <td>5500</td>
      <td>18</td>
      <td>23</td>
      <td>21485.0</td>
    </tr>
    <tr>
      <th>203</th>
      <td>204</td>
      <td>-1</td>
      <td>volvo 246</td>
      <td>turbo</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>109.1</td>
      <td>188.8</td>
      <td>68.9</td>
      <td>55.5</td>
      <td>...</td>
      <td>145</td>
      <td>idi</td>
      <td>3.01</td>
      <td>3.40</td>
      <td>23.0</td>
      <td>106</td>
      <td>4800</td>
      <td>26</td>
      <td>27</td>
      <td>22470.0</td>
    </tr>
    <tr>
      <th>204</th>
      <td>205</td>
      <td>-1</td>
      <td>volvo 264gl</td>
      <td>turbo</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>109.1</td>
      <td>188.8</td>
      <td>68.9</td>
      <td>55.5</td>
      <td>...</td>
      <td>141</td>
      <td>mpfi</td>
      <td>3.78</td>
      <td>3.15</td>
      <td>9.5</td>
      <td>114</td>
      <td>5400</td>
      <td>19</td>
      <td>25</td>
      <td>22625.0</td>
    </tr>
  </tbody>
</table>
<p>205 rows × 23 columns</p>
</div>




```python
print(df['aspiration'].unique()) 
```

    ['std' 'turbo']
    


```python
df['aspiration']=df['aspiration'].map({'std':0,'turbo':1})
```


```python
import seaborn as sns
import matplotlib.pyplot as plt

df_numeric = df.select_dtypes(include=['number'])

plt.figure(figsize=(10,6))
sns.heatmap(df_numeric.corr(), annot=True, cmap="coolwarm")
plt.title("Feature Correlation Heatmap")
plt.show()
```


    
![png](output_49_0.png)
    


Dropping 'aspiration' column


```python
df.drop(columns=['aspiration'],axis=1,inplace=True)
```

Removing 'stroke' column


```python
df.drop(columns=['stroke'],axis=1,inplace=True)
```

Sorting the table by 'price'(Ascending order)


```python
df.sort_values(by='price', ascending=True, inplace=True)
```


```python
df['price'].head()
```




    138    5118.0
    18     5151.0
    50     5195.0
    150    5348.0
    76     5389.0
    Name: price, dtype: float64




```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>car_ID</th>
      <th>symboling</th>
      <th>CarName</th>
      <th>carbody</th>
      <th>drivewheel</th>
      <th>wheelbase</th>
      <th>carlength</th>
      <th>carwidth</th>
      <th>carheight</th>
      <th>curbweight</th>
      <th>...</th>
      <th>cylindernumber</th>
      <th>enginesize</th>
      <th>fuelsystem</th>
      <th>boreratio</th>
      <th>compressionratio</th>
      <th>horsepower</th>
      <th>peakrpm</th>
      <th>citympg</th>
      <th>highwaympg</th>
      <th>price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>138</th>
      <td>139</td>
      <td>2</td>
      <td>subaru</td>
      <td>hatchback</td>
      <td>fwd</td>
      <td>93.7</td>
      <td>156.9</td>
      <td>63.4</td>
      <td>53.7</td>
      <td>2050</td>
      <td>...</td>
      <td>four</td>
      <td>97</td>
      <td>2bbl</td>
      <td>3.62</td>
      <td>9.0</td>
      <td>69</td>
      <td>4900</td>
      <td>31</td>
      <td>36</td>
      <td>5118.0</td>
    </tr>
    <tr>
      <th>18</th>
      <td>19</td>
      <td>2</td>
      <td>chevrolet impala</td>
      <td>hatchback</td>
      <td>fwd</td>
      <td>88.4</td>
      <td>141.1</td>
      <td>60.3</td>
      <td>53.2</td>
      <td>1488</td>
      <td>...</td>
      <td>three</td>
      <td>61</td>
      <td>2bbl</td>
      <td>2.91</td>
      <td>9.5</td>
      <td>48</td>
      <td>5100</td>
      <td>47</td>
      <td>53</td>
      <td>5151.0</td>
    </tr>
    <tr>
      <th>50</th>
      <td>51</td>
      <td>1</td>
      <td>maxda rx3</td>
      <td>hatchback</td>
      <td>fwd</td>
      <td>93.1</td>
      <td>159.1</td>
      <td>64.2</td>
      <td>54.1</td>
      <td>1890</td>
      <td>...</td>
      <td>four</td>
      <td>91</td>
      <td>2bbl</td>
      <td>3.03</td>
      <td>9.0</td>
      <td>68</td>
      <td>5000</td>
      <td>30</td>
      <td>31</td>
      <td>5195.0</td>
    </tr>
    <tr>
      <th>150</th>
      <td>151</td>
      <td>1</td>
      <td>toyota corona mark ii</td>
      <td>hatchback</td>
      <td>fwd</td>
      <td>95.7</td>
      <td>158.7</td>
      <td>63.6</td>
      <td>54.5</td>
      <td>1985</td>
      <td>...</td>
      <td>four</td>
      <td>92</td>
      <td>2bbl</td>
      <td>3.05</td>
      <td>9.0</td>
      <td>62</td>
      <td>4800</td>
      <td>35</td>
      <td>39</td>
      <td>5348.0</td>
    </tr>
    <tr>
      <th>76</th>
      <td>77</td>
      <td>2</td>
      <td>mitsubishi mirage</td>
      <td>hatchback</td>
      <td>fwd</td>
      <td>93.7</td>
      <td>157.3</td>
      <td>64.4</td>
      <td>50.8</td>
      <td>1918</td>
      <td>...</td>
      <td>four</td>
      <td>92</td>
      <td>2bbl</td>
      <td>2.97</td>
      <td>9.4</td>
      <td>68</td>
      <td>5500</td>
      <td>37</td>
      <td>41</td>
      <td>5389.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>17</th>
      <td>18</td>
      <td>0</td>
      <td>bmw x3</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>110.0</td>
      <td>197.0</td>
      <td>70.9</td>
      <td>56.3</td>
      <td>3505</td>
      <td>...</td>
      <td>six</td>
      <td>209</td>
      <td>mpfi</td>
      <td>3.62</td>
      <td>8.0</td>
      <td>182</td>
      <td>5400</td>
      <td>15</td>
      <td>20</td>
      <td>36880.0</td>
    </tr>
    <tr>
      <th>128</th>
      <td>129</td>
      <td>3</td>
      <td>porsche boxter</td>
      <td>convertible</td>
      <td>rwd</td>
      <td>89.5</td>
      <td>168.9</td>
      <td>65.0</td>
      <td>51.6</td>
      <td>2800</td>
      <td>...</td>
      <td>six</td>
      <td>194</td>
      <td>mpfi</td>
      <td>3.74</td>
      <td>9.5</td>
      <td>207</td>
      <td>5900</td>
      <td>17</td>
      <td>25</td>
      <td>37028.0</td>
    </tr>
    <tr>
      <th>73</th>
      <td>74</td>
      <td>0</td>
      <td>buick century special</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>120.9</td>
      <td>208.1</td>
      <td>71.7</td>
      <td>56.7</td>
      <td>3900</td>
      <td>...</td>
      <td>eight</td>
      <td>308</td>
      <td>mpfi</td>
      <td>3.80</td>
      <td>8.0</td>
      <td>184</td>
      <td>4500</td>
      <td>14</td>
      <td>16</td>
      <td>40960.0</td>
    </tr>
    <tr>
      <th>16</th>
      <td>17</td>
      <td>0</td>
      <td>bmw x5</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>103.5</td>
      <td>193.8</td>
      <td>67.9</td>
      <td>53.7</td>
      <td>3380</td>
      <td>...</td>
      <td>six</td>
      <td>209</td>
      <td>mpfi</td>
      <td>3.62</td>
      <td>8.0</td>
      <td>182</td>
      <td>5400</td>
      <td>16</td>
      <td>22</td>
      <td>41315.0</td>
    </tr>
    <tr>
      <th>74</th>
      <td>75</td>
      <td>1</td>
      <td>buick regal sport coupe (turbo)</td>
      <td>hardtop</td>
      <td>rwd</td>
      <td>112.0</td>
      <td>199.2</td>
      <td>72.0</td>
      <td>55.4</td>
      <td>3715</td>
      <td>...</td>
      <td>eight</td>
      <td>304</td>
      <td>mpfi</td>
      <td>3.80</td>
      <td>8.0</td>
      <td>184</td>
      <td>4500</td>
      <td>14</td>
      <td>16</td>
      <td>45400.0</td>
    </tr>
  </tbody>
</table>
<p>205 rows × 21 columns</p>
</div>



Data Visualization

Pairplot


```python
import seaborn as sns
import matplotlib.pyplot as plt
```


```python
selected_features = ['price', 'horsepower', 'curbweight', 'citympg', 'enginesize']
sns.pairplot(df[selected_features], diag_kind='kde')
plt.show()
```


    
![png](output_61_0.png)
    


Heatmap


```python
plt.figure(figsize=(10,6))
sns.heatmap(df_numeric.corr(), annot=True, cmap="coolwarm", linewidths=0.5)
plt.title("Feature Correlation Heatmap")
plt.show()
```


    
![png](output_63_0.png)
    



```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>car_ID</th>
      <th>symboling</th>
      <th>CarName</th>
      <th>carbody</th>
      <th>drivewheel</th>
      <th>wheelbase</th>
      <th>carlength</th>
      <th>carwidth</th>
      <th>carheight</th>
      <th>curbweight</th>
      <th>...</th>
      <th>cylindernumber</th>
      <th>enginesize</th>
      <th>fuelsystem</th>
      <th>boreratio</th>
      <th>compressionratio</th>
      <th>horsepower</th>
      <th>peakrpm</th>
      <th>citympg</th>
      <th>highwaympg</th>
      <th>price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>138</th>
      <td>139</td>
      <td>2</td>
      <td>subaru</td>
      <td>hatchback</td>
      <td>fwd</td>
      <td>93.7</td>
      <td>156.9</td>
      <td>63.4</td>
      <td>53.7</td>
      <td>2050</td>
      <td>...</td>
      <td>four</td>
      <td>97</td>
      <td>2bbl</td>
      <td>3.62</td>
      <td>9.0</td>
      <td>69</td>
      <td>4900</td>
      <td>31</td>
      <td>36</td>
      <td>5118.0</td>
    </tr>
    <tr>
      <th>18</th>
      <td>19</td>
      <td>2</td>
      <td>chevrolet impala</td>
      <td>hatchback</td>
      <td>fwd</td>
      <td>88.4</td>
      <td>141.1</td>
      <td>60.3</td>
      <td>53.2</td>
      <td>1488</td>
      <td>...</td>
      <td>three</td>
      <td>61</td>
      <td>2bbl</td>
      <td>2.91</td>
      <td>9.5</td>
      <td>48</td>
      <td>5100</td>
      <td>47</td>
      <td>53</td>
      <td>5151.0</td>
    </tr>
    <tr>
      <th>50</th>
      <td>51</td>
      <td>1</td>
      <td>maxda rx3</td>
      <td>hatchback</td>
      <td>fwd</td>
      <td>93.1</td>
      <td>159.1</td>
      <td>64.2</td>
      <td>54.1</td>
      <td>1890</td>
      <td>...</td>
      <td>four</td>
      <td>91</td>
      <td>2bbl</td>
      <td>3.03</td>
      <td>9.0</td>
      <td>68</td>
      <td>5000</td>
      <td>30</td>
      <td>31</td>
      <td>5195.0</td>
    </tr>
    <tr>
      <th>150</th>
      <td>151</td>
      <td>1</td>
      <td>toyota corona mark ii</td>
      <td>hatchback</td>
      <td>fwd</td>
      <td>95.7</td>
      <td>158.7</td>
      <td>63.6</td>
      <td>54.5</td>
      <td>1985</td>
      <td>...</td>
      <td>four</td>
      <td>92</td>
      <td>2bbl</td>
      <td>3.05</td>
      <td>9.0</td>
      <td>62</td>
      <td>4800</td>
      <td>35</td>
      <td>39</td>
      <td>5348.0</td>
    </tr>
    <tr>
      <th>76</th>
      <td>77</td>
      <td>2</td>
      <td>mitsubishi mirage</td>
      <td>hatchback</td>
      <td>fwd</td>
      <td>93.7</td>
      <td>157.3</td>
      <td>64.4</td>
      <td>50.8</td>
      <td>1918</td>
      <td>...</td>
      <td>four</td>
      <td>92</td>
      <td>2bbl</td>
      <td>2.97</td>
      <td>9.4</td>
      <td>68</td>
      <td>5500</td>
      <td>37</td>
      <td>41</td>
      <td>5389.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>17</th>
      <td>18</td>
      <td>0</td>
      <td>bmw x3</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>110.0</td>
      <td>197.0</td>
      <td>70.9</td>
      <td>56.3</td>
      <td>3505</td>
      <td>...</td>
      <td>six</td>
      <td>209</td>
      <td>mpfi</td>
      <td>3.62</td>
      <td>8.0</td>
      <td>182</td>
      <td>5400</td>
      <td>15</td>
      <td>20</td>
      <td>36880.0</td>
    </tr>
    <tr>
      <th>128</th>
      <td>129</td>
      <td>3</td>
      <td>porsche boxter</td>
      <td>convertible</td>
      <td>rwd</td>
      <td>89.5</td>
      <td>168.9</td>
      <td>65.0</td>
      <td>51.6</td>
      <td>2800</td>
      <td>...</td>
      <td>six</td>
      <td>194</td>
      <td>mpfi</td>
      <td>3.74</td>
      <td>9.5</td>
      <td>207</td>
      <td>5900</td>
      <td>17</td>
      <td>25</td>
      <td>37028.0</td>
    </tr>
    <tr>
      <th>73</th>
      <td>74</td>
      <td>0</td>
      <td>buick century special</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>120.9</td>
      <td>208.1</td>
      <td>71.7</td>
      <td>56.7</td>
      <td>3900</td>
      <td>...</td>
      <td>eight</td>
      <td>308</td>
      <td>mpfi</td>
      <td>3.80</td>
      <td>8.0</td>
      <td>184</td>
      <td>4500</td>
      <td>14</td>
      <td>16</td>
      <td>40960.0</td>
    </tr>
    <tr>
      <th>16</th>
      <td>17</td>
      <td>0</td>
      <td>bmw x5</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>103.5</td>
      <td>193.8</td>
      <td>67.9</td>
      <td>53.7</td>
      <td>3380</td>
      <td>...</td>
      <td>six</td>
      <td>209</td>
      <td>mpfi</td>
      <td>3.62</td>
      <td>8.0</td>
      <td>182</td>
      <td>5400</td>
      <td>16</td>
      <td>22</td>
      <td>41315.0</td>
    </tr>
    <tr>
      <th>74</th>
      <td>75</td>
      <td>1</td>
      <td>buick regal sport coupe (turbo)</td>
      <td>hardtop</td>
      <td>rwd</td>
      <td>112.0</td>
      <td>199.2</td>
      <td>72.0</td>
      <td>55.4</td>
      <td>3715</td>
      <td>...</td>
      <td>eight</td>
      <td>304</td>
      <td>mpfi</td>
      <td>3.80</td>
      <td>8.0</td>
      <td>184</td>
      <td>4500</td>
      <td>14</td>
      <td>16</td>
      <td>45400.0</td>
    </tr>
  </tbody>
</table>
<p>205 rows × 21 columns</p>
</div>




```python
%store df
```

    Stored 'df' (DataFrame)
    

    C:\Users\amogh\AppData\Local\Programs\Python\Python312\Lib\site-packages\IPython\extensions\storemagic.py:229: UserWarning: This is now an optional IPython functionality, setting autorestore/df requires you to install the `pickleshare` library.
      db[ 'autorestore/' + arg ] = obj
    


```python
!pip install pickleshare
```

    Requirement already satisfied: pickleshare in c:\users\amogh\appdata\local\programs\python\python312\lib\site-packages (0.7.5)
    

    
    [notice] A new release of pip is available: 24.1.1 -> 25.0.1
    [notice] To update, run: python.exe -m pip install --upgrade pip
    


```python
%store df
```

    Stored 'df' (DataFrame)
    


```python
df.to_csv("updated_df.csv",index=False)
```


```python
import pandas as pd
df = pd.read_csv("updated_df.csv")
```


```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>car_ID</th>
      <th>symboling</th>
      <th>CarName</th>
      <th>carbody</th>
      <th>drivewheel</th>
      <th>wheelbase</th>
      <th>carlength</th>
      <th>carwidth</th>
      <th>carheight</th>
      <th>curbweight</th>
      <th>...</th>
      <th>cylindernumber</th>
      <th>enginesize</th>
      <th>fuelsystem</th>
      <th>boreratio</th>
      <th>compressionratio</th>
      <th>horsepower</th>
      <th>peakrpm</th>
      <th>citympg</th>
      <th>highwaympg</th>
      <th>price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>139</td>
      <td>2</td>
      <td>subaru</td>
      <td>hatchback</td>
      <td>fwd</td>
      <td>93.7</td>
      <td>156.9</td>
      <td>63.4</td>
      <td>53.7</td>
      <td>2050</td>
      <td>...</td>
      <td>four</td>
      <td>97</td>
      <td>2bbl</td>
      <td>3.62</td>
      <td>9.0</td>
      <td>69</td>
      <td>4900</td>
      <td>31</td>
      <td>36</td>
      <td>5118.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>19</td>
      <td>2</td>
      <td>chevrolet impala</td>
      <td>hatchback</td>
      <td>fwd</td>
      <td>88.4</td>
      <td>141.1</td>
      <td>60.3</td>
      <td>53.2</td>
      <td>1488</td>
      <td>...</td>
      <td>three</td>
      <td>61</td>
      <td>2bbl</td>
      <td>2.91</td>
      <td>9.5</td>
      <td>48</td>
      <td>5100</td>
      <td>47</td>
      <td>53</td>
      <td>5151.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>51</td>
      <td>1</td>
      <td>maxda rx3</td>
      <td>hatchback</td>
      <td>fwd</td>
      <td>93.1</td>
      <td>159.1</td>
      <td>64.2</td>
      <td>54.1</td>
      <td>1890</td>
      <td>...</td>
      <td>four</td>
      <td>91</td>
      <td>2bbl</td>
      <td>3.03</td>
      <td>9.0</td>
      <td>68</td>
      <td>5000</td>
      <td>30</td>
      <td>31</td>
      <td>5195.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>151</td>
      <td>1</td>
      <td>toyota corona mark ii</td>
      <td>hatchback</td>
      <td>fwd</td>
      <td>95.7</td>
      <td>158.7</td>
      <td>63.6</td>
      <td>54.5</td>
      <td>1985</td>
      <td>...</td>
      <td>four</td>
      <td>92</td>
      <td>2bbl</td>
      <td>3.05</td>
      <td>9.0</td>
      <td>62</td>
      <td>4800</td>
      <td>35</td>
      <td>39</td>
      <td>5348.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>77</td>
      <td>2</td>
      <td>mitsubishi mirage</td>
      <td>hatchback</td>
      <td>fwd</td>
      <td>93.7</td>
      <td>157.3</td>
      <td>64.4</td>
      <td>50.8</td>
      <td>1918</td>
      <td>...</td>
      <td>four</td>
      <td>92</td>
      <td>2bbl</td>
      <td>2.97</td>
      <td>9.4</td>
      <td>68</td>
      <td>5500</td>
      <td>37</td>
      <td>41</td>
      <td>5389.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>200</th>
      <td>18</td>
      <td>0</td>
      <td>bmw x3</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>110.0</td>
      <td>197.0</td>
      <td>70.9</td>
      <td>56.3</td>
      <td>3505</td>
      <td>...</td>
      <td>six</td>
      <td>209</td>
      <td>mpfi</td>
      <td>3.62</td>
      <td>8.0</td>
      <td>182</td>
      <td>5400</td>
      <td>15</td>
      <td>20</td>
      <td>36880.0</td>
    </tr>
    <tr>
      <th>201</th>
      <td>129</td>
      <td>3</td>
      <td>porsche boxter</td>
      <td>convertible</td>
      <td>rwd</td>
      <td>89.5</td>
      <td>168.9</td>
      <td>65.0</td>
      <td>51.6</td>
      <td>2800</td>
      <td>...</td>
      <td>six</td>
      <td>194</td>
      <td>mpfi</td>
      <td>3.74</td>
      <td>9.5</td>
      <td>207</td>
      <td>5900</td>
      <td>17</td>
      <td>25</td>
      <td>37028.0</td>
    </tr>
    <tr>
      <th>202</th>
      <td>74</td>
      <td>0</td>
      <td>buick century special</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>120.9</td>
      <td>208.1</td>
      <td>71.7</td>
      <td>56.7</td>
      <td>3900</td>
      <td>...</td>
      <td>eight</td>
      <td>308</td>
      <td>mpfi</td>
      <td>3.80</td>
      <td>8.0</td>
      <td>184</td>
      <td>4500</td>
      <td>14</td>
      <td>16</td>
      <td>40960.0</td>
    </tr>
    <tr>
      <th>203</th>
      <td>17</td>
      <td>0</td>
      <td>bmw x5</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>103.5</td>
      <td>193.8</td>
      <td>67.9</td>
      <td>53.7</td>
      <td>3380</td>
      <td>...</td>
      <td>six</td>
      <td>209</td>
      <td>mpfi</td>
      <td>3.62</td>
      <td>8.0</td>
      <td>182</td>
      <td>5400</td>
      <td>16</td>
      <td>22</td>
      <td>41315.0</td>
    </tr>
    <tr>
      <th>204</th>
      <td>75</td>
      <td>1</td>
      <td>buick regal sport coupe (turbo)</td>
      <td>hardtop</td>
      <td>rwd</td>
      <td>112.0</td>
      <td>199.2</td>
      <td>72.0</td>
      <td>55.4</td>
      <td>3715</td>
      <td>...</td>
      <td>eight</td>
      <td>304</td>
      <td>mpfi</td>
      <td>3.80</td>
      <td>8.0</td>
      <td>184</td>
      <td>4500</td>
      <td>14</td>
      <td>16</td>
      <td>45400.0</td>
    </tr>
  </tbody>
</table>
<p>205 rows × 21 columns</p>
</div>




```python
df.to_csv("updated_df.csv",index=False)
```


```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>car_ID</th>
      <th>symboling</th>
      <th>CarName</th>
      <th>carbody</th>
      <th>drivewheel</th>
      <th>wheelbase</th>
      <th>carlength</th>
      <th>carwidth</th>
      <th>carheight</th>
      <th>curbweight</th>
      <th>...</th>
      <th>cylindernumber</th>
      <th>enginesize</th>
      <th>fuelsystem</th>
      <th>boreratio</th>
      <th>compressionratio</th>
      <th>horsepower</th>
      <th>peakrpm</th>
      <th>citympg</th>
      <th>highwaympg</th>
      <th>price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>139</td>
      <td>2</td>
      <td>subaru</td>
      <td>hatchback</td>
      <td>fwd</td>
      <td>93.7</td>
      <td>156.9</td>
      <td>63.4</td>
      <td>53.7</td>
      <td>2050</td>
      <td>...</td>
      <td>four</td>
      <td>97</td>
      <td>2bbl</td>
      <td>3.62</td>
      <td>9.0</td>
      <td>69</td>
      <td>4900</td>
      <td>31</td>
      <td>36</td>
      <td>5118.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>19</td>
      <td>2</td>
      <td>chevrolet impala</td>
      <td>hatchback</td>
      <td>fwd</td>
      <td>88.4</td>
      <td>141.1</td>
      <td>60.3</td>
      <td>53.2</td>
      <td>1488</td>
      <td>...</td>
      <td>three</td>
      <td>61</td>
      <td>2bbl</td>
      <td>2.91</td>
      <td>9.5</td>
      <td>48</td>
      <td>5100</td>
      <td>47</td>
      <td>53</td>
      <td>5151.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>51</td>
      <td>1</td>
      <td>maxda rx3</td>
      <td>hatchback</td>
      <td>fwd</td>
      <td>93.1</td>
      <td>159.1</td>
      <td>64.2</td>
      <td>54.1</td>
      <td>1890</td>
      <td>...</td>
      <td>four</td>
      <td>91</td>
      <td>2bbl</td>
      <td>3.03</td>
      <td>9.0</td>
      <td>68</td>
      <td>5000</td>
      <td>30</td>
      <td>31</td>
      <td>5195.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>151</td>
      <td>1</td>
      <td>toyota corona mark ii</td>
      <td>hatchback</td>
      <td>fwd</td>
      <td>95.7</td>
      <td>158.7</td>
      <td>63.6</td>
      <td>54.5</td>
      <td>1985</td>
      <td>...</td>
      <td>four</td>
      <td>92</td>
      <td>2bbl</td>
      <td>3.05</td>
      <td>9.0</td>
      <td>62</td>
      <td>4800</td>
      <td>35</td>
      <td>39</td>
      <td>5348.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>77</td>
      <td>2</td>
      <td>mitsubishi mirage</td>
      <td>hatchback</td>
      <td>fwd</td>
      <td>93.7</td>
      <td>157.3</td>
      <td>64.4</td>
      <td>50.8</td>
      <td>1918</td>
      <td>...</td>
      <td>four</td>
      <td>92</td>
      <td>2bbl</td>
      <td>2.97</td>
      <td>9.4</td>
      <td>68</td>
      <td>5500</td>
      <td>37</td>
      <td>41</td>
      <td>5389.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>200</th>
      <td>18</td>
      <td>0</td>
      <td>bmw x3</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>110.0</td>
      <td>197.0</td>
      <td>70.9</td>
      <td>56.3</td>
      <td>3505</td>
      <td>...</td>
      <td>six</td>
      <td>209</td>
      <td>mpfi</td>
      <td>3.62</td>
      <td>8.0</td>
      <td>182</td>
      <td>5400</td>
      <td>15</td>
      <td>20</td>
      <td>36880.0</td>
    </tr>
    <tr>
      <th>201</th>
      <td>129</td>
      <td>3</td>
      <td>porsche boxter</td>
      <td>convertible</td>
      <td>rwd</td>
      <td>89.5</td>
      <td>168.9</td>
      <td>65.0</td>
      <td>51.6</td>
      <td>2800</td>
      <td>...</td>
      <td>six</td>
      <td>194</td>
      <td>mpfi</td>
      <td>3.74</td>
      <td>9.5</td>
      <td>207</td>
      <td>5900</td>
      <td>17</td>
      <td>25</td>
      <td>37028.0</td>
    </tr>
    <tr>
      <th>202</th>
      <td>74</td>
      <td>0</td>
      <td>buick century special</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>120.9</td>
      <td>208.1</td>
      <td>71.7</td>
      <td>56.7</td>
      <td>3900</td>
      <td>...</td>
      <td>eight</td>
      <td>308</td>
      <td>mpfi</td>
      <td>3.80</td>
      <td>8.0</td>
      <td>184</td>
      <td>4500</td>
      <td>14</td>
      <td>16</td>
      <td>40960.0</td>
    </tr>
    <tr>
      <th>203</th>
      <td>17</td>
      <td>0</td>
      <td>bmw x5</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>103.5</td>
      <td>193.8</td>
      <td>67.9</td>
      <td>53.7</td>
      <td>3380</td>
      <td>...</td>
      <td>six</td>
      <td>209</td>
      <td>mpfi</td>
      <td>3.62</td>
      <td>8.0</td>
      <td>182</td>
      <td>5400</td>
      <td>16</td>
      <td>22</td>
      <td>41315.0</td>
    </tr>
    <tr>
      <th>204</th>
      <td>75</td>
      <td>1</td>
      <td>buick regal sport coupe (turbo)</td>
      <td>hardtop</td>
      <td>rwd</td>
      <td>112.0</td>
      <td>199.2</td>
      <td>72.0</td>
      <td>55.4</td>
      <td>3715</td>
      <td>...</td>
      <td>eight</td>
      <td>304</td>
      <td>mpfi</td>
      <td>3.80</td>
      <td>8.0</td>
      <td>184</td>
      <td>4500</td>
      <td>14</td>
      <td>16</td>
      <td>45400.0</td>
    </tr>
  </tbody>
</table>
<p>205 rows × 21 columns</p>
</div>



Data Preperation


```python
df['carCompany'] = df['CarName'].apply(lambda x: x.split(' ')[0].lower())  
```


```python
df['carCompany']
```




    0          subaru
    1       chevrolet
    2           maxda
    3          toyota
    4      mitsubishi
              ...    
    200           bmw
    201       porsche
    202         buick
    203           bmw
    204         buick
    Name: carCompany, Length: 205, dtype: object




```python
print(df['carCompany'].unique())
```

    ['subaru' 'chevrolet' 'maxda' 'toyota' 'mitsubishi' 'honda' 'nissan'
     'plymouth' 'dodge' 'mazda' 'isuzu' 'vokswagen' 'volkswagen' 'renault'
     'vw' 'saab' 'peugeot' 'volvo' 'alfa-romero' 'audi' 'toyouta' 'bmw'
     'mercury' 'porsche' 'buick' 'jaguar' 'porcshce']
    


```python
df['carCompany']=df['carCompany'].replace({
    'maxda': 'mazda',         
    'vokswagen': 'volkswagen', 
    'vw': 'volkswagen',        
    'toyouta': 'toyota',      
    'porcshce': 'porsche',     
    'alfa-romero': 'alfa-romeo'
})
```


```python
df['carCompany'].unique()
```




    array(['subaru', 'chevrolet', 'mazda', 'toyota', 'mitsubishi', 'honda',
           'nissan', 'plymouth', 'dodge', 'isuzu', 'volkswagen', 'renault',
           'saab', 'peugeot', 'volvo', 'alfa-romeo', 'audi', 'bmw', 'mercury',
           'porsche', 'buick', 'jaguar'], dtype=object)



Dropping 'car_ID' column


```python
df.drop(columns=['car_ID'], axis=1, inplace=True)
```


```python
df = pd.get_dummies(df, columns=['carCompany', 'enginetype', 'carbody'], drop_first=True)
```


```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>symboling</th>
      <th>CarName</th>
      <th>drivewheel</th>
      <th>wheelbase</th>
      <th>carlength</th>
      <th>carwidth</th>
      <th>carheight</th>
      <th>curbweight</th>
      <th>cylindernumber</th>
      <th>enginesize</th>
      <th>...</th>
      <th>enginetype_dohcv</th>
      <th>enginetype_l</th>
      <th>enginetype_ohc</th>
      <th>enginetype_ohcf</th>
      <th>enginetype_ohcv</th>
      <th>enginetype_rotor</th>
      <th>carbody_hardtop</th>
      <th>carbody_hatchback</th>
      <th>carbody_sedan</th>
      <th>carbody_wagon</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2</td>
      <td>subaru</td>
      <td>fwd</td>
      <td>93.7</td>
      <td>156.9</td>
      <td>63.4</td>
      <td>53.7</td>
      <td>2050</td>
      <td>four</td>
      <td>97</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>chevrolet impala</td>
      <td>fwd</td>
      <td>88.4</td>
      <td>141.1</td>
      <td>60.3</td>
      <td>53.2</td>
      <td>1488</td>
      <td>three</td>
      <td>61</td>
      <td>...</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>maxda rx3</td>
      <td>fwd</td>
      <td>93.1</td>
      <td>159.1</td>
      <td>64.2</td>
      <td>54.1</td>
      <td>1890</td>
      <td>four</td>
      <td>91</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>toyota corona mark ii</td>
      <td>fwd</td>
      <td>95.7</td>
      <td>158.7</td>
      <td>63.6</td>
      <td>54.5</td>
      <td>1985</td>
      <td>four</td>
      <td>92</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2</td>
      <td>mitsubishi mirage</td>
      <td>fwd</td>
      <td>93.7</td>
      <td>157.3</td>
      <td>64.4</td>
      <td>50.8</td>
      <td>1918</td>
      <td>four</td>
      <td>92</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>200</th>
      <td>0</td>
      <td>bmw x3</td>
      <td>rwd</td>
      <td>110.0</td>
      <td>197.0</td>
      <td>70.9</td>
      <td>56.3</td>
      <td>3505</td>
      <td>six</td>
      <td>209</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
    </tr>
    <tr>
      <th>201</th>
      <td>3</td>
      <td>porsche boxter</td>
      <td>rwd</td>
      <td>89.5</td>
      <td>168.9</td>
      <td>65.0</td>
      <td>51.6</td>
      <td>2800</td>
      <td>six</td>
      <td>194</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>202</th>
      <td>0</td>
      <td>buick century special</td>
      <td>rwd</td>
      <td>120.9</td>
      <td>208.1</td>
      <td>71.7</td>
      <td>56.7</td>
      <td>3900</td>
      <td>eight</td>
      <td>308</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
    </tr>
    <tr>
      <th>203</th>
      <td>0</td>
      <td>bmw x5</td>
      <td>rwd</td>
      <td>103.5</td>
      <td>193.8</td>
      <td>67.9</td>
      <td>53.7</td>
      <td>3380</td>
      <td>six</td>
      <td>209</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
    </tr>
    <tr>
      <th>204</th>
      <td>1</td>
      <td>buick regal sport coupe (turbo)</td>
      <td>rwd</td>
      <td>112.0</td>
      <td>199.2</td>
      <td>72.0</td>
      <td>55.4</td>
      <td>3715</td>
      <td>eight</td>
      <td>304</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
<p>205 rows × 49 columns</p>
</div>




```python
df.to_csv("updated_df.csv",index=False)
```


```python
df.rename(columns={
    'carCompany_subaru': 'is_subaru',
    'carCompany_chevrolet': 'is_chevrolet',
    'carCompany_mazda': 'is_mazda',
    'carCompany_toyota': 'is_toyota',
    'carCompany_mitsubishi': 'is_mitsubishi',
    'carCompany_honda': 'is_honda',
    'carCompany_nissan': 'is_nissan',
    'carCompany_plymouth': 'is_plymouth',
    'carCompany_dodge': 'is_dodge',
    'carCompany_isuzu': 'is_isuzu',
    'carCompany_volkswagen': 'is_volkswagen',
    'carCompany_renault': 'is_renault',
    'carCompany_saab': 'is_saab',
    'carCompany_peugeot': 'is_peugeot',
    'carCompany_volvo': 'is_volvo',
    'carCompany_alfa-romeo': 'is_alfa_romeo',
    'carCompany_audi': 'is_audi',
    'carCompany_bmw': 'is_bmw',
    'carCompany_mercury': 'is_mercury',
    'carCompany_porsche': 'is_porsche',
    'carCompany_buick': 'is_buick',
    'carCompany_jaguar': 'is_jaguar'
}, inplace=True)
```


```python
df.rename(columns={
    'enginetype_dohcv': 'is_dohcv',
    'enginetype_I': 'is_inline',
    'enginetype_ohc': 'is_ohc',
    'enginetype_ohcf': 'is_ohcf',
    'enginetype_ohcv': 'is_ohcv',
    'enginetype_rotor': 'is_rotor'
}, inplace=True)
```


```python
df.rename(columns={
    'carbody_hardtop': 'is_hardtop',
    'carbody_sedan': 'is_sedan',
    'carbody_hatchback': 'is_hatchback',
    'carbody_wagon': 'is_wagon'
}, inplace=True)
```


```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>symboling</th>
      <th>CarName</th>
      <th>drivewheel</th>
      <th>wheelbase</th>
      <th>carlength</th>
      <th>carwidth</th>
      <th>carheight</th>
      <th>curbweight</th>
      <th>cylindernumber</th>
      <th>enginesize</th>
      <th>...</th>
      <th>is_dohcv</th>
      <th>enginetype_l</th>
      <th>is_ohc</th>
      <th>is_ohcf</th>
      <th>is_ohcv</th>
      <th>is_rotor</th>
      <th>is_hardtop</th>
      <th>is_hatchback</th>
      <th>is_sedan</th>
      <th>is_wagon</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2</td>
      <td>subaru</td>
      <td>fwd</td>
      <td>93.7</td>
      <td>156.9</td>
      <td>63.4</td>
      <td>53.7</td>
      <td>2050</td>
      <td>four</td>
      <td>97</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>chevrolet impala</td>
      <td>fwd</td>
      <td>88.4</td>
      <td>141.1</td>
      <td>60.3</td>
      <td>53.2</td>
      <td>1488</td>
      <td>three</td>
      <td>61</td>
      <td>...</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>maxda rx3</td>
      <td>fwd</td>
      <td>93.1</td>
      <td>159.1</td>
      <td>64.2</td>
      <td>54.1</td>
      <td>1890</td>
      <td>four</td>
      <td>91</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>toyota corona mark ii</td>
      <td>fwd</td>
      <td>95.7</td>
      <td>158.7</td>
      <td>63.6</td>
      <td>54.5</td>
      <td>1985</td>
      <td>four</td>
      <td>92</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2</td>
      <td>mitsubishi mirage</td>
      <td>fwd</td>
      <td>93.7</td>
      <td>157.3</td>
      <td>64.4</td>
      <td>50.8</td>
      <td>1918</td>
      <td>four</td>
      <td>92</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>200</th>
      <td>0</td>
      <td>bmw x3</td>
      <td>rwd</td>
      <td>110.0</td>
      <td>197.0</td>
      <td>70.9</td>
      <td>56.3</td>
      <td>3505</td>
      <td>six</td>
      <td>209</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
    </tr>
    <tr>
      <th>201</th>
      <td>3</td>
      <td>porsche boxter</td>
      <td>rwd</td>
      <td>89.5</td>
      <td>168.9</td>
      <td>65.0</td>
      <td>51.6</td>
      <td>2800</td>
      <td>six</td>
      <td>194</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>202</th>
      <td>0</td>
      <td>buick century special</td>
      <td>rwd</td>
      <td>120.9</td>
      <td>208.1</td>
      <td>71.7</td>
      <td>56.7</td>
      <td>3900</td>
      <td>eight</td>
      <td>308</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
    </tr>
    <tr>
      <th>203</th>
      <td>0</td>
      <td>bmw x5</td>
      <td>rwd</td>
      <td>103.5</td>
      <td>193.8</td>
      <td>67.9</td>
      <td>53.7</td>
      <td>3380</td>
      <td>six</td>
      <td>209</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
    </tr>
    <tr>
      <th>204</th>
      <td>1</td>
      <td>buick regal sport coupe (turbo)</td>
      <td>rwd</td>
      <td>112.0</td>
      <td>199.2</td>
      <td>72.0</td>
      <td>55.4</td>
      <td>3715</td>
      <td>eight</td>
      <td>304</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
<p>205 rows × 49 columns</p>
</div>




```python
df.to_csv("updated_df.csv",index=False)
```


```python
df['car_stability'] = df['wheelbase'] / df['carlength']
```


```python
df['car_stability']
```




    0      0.597196
    1      0.626506
    2      0.585167
    3      0.603025
    4      0.595677
             ...   
    200    0.558376
    201    0.529899
    202    0.580971
    203    0.534056
    204    0.562249
    Name: car_stability, Length: 205, dtype: float64




```python
import seaborn as sns
import matplotlib.pyplot as plt

df_numeric = df.select_dtypes(include=['number']) 

plt.figure(figsize=(10,6))
sns.heatmap(df_numeric.corr(), annot=True, cmap="coolwarm")
plt.title("Feature Correlation Heatmap")
plt.show()
```


    
![png](output_91_0.png)
    



```python
import seaborn as sns
import matplotlib.pyplot as plt

correlation_matrix = df[['wheelbase', 'carlength', 'car_stability', 'price']].corr()

print(correlation_matrix)

```

                   wheelbase  carlength  car_stability     price
    wheelbase       1.000000   0.874587      -0.058602  0.577816
    carlength       0.874587   1.000000      -0.533972  0.682920
    car_stability  -0.058602  -0.533972       1.000000 -0.389469
    price           0.577816   0.682920      -0.389469  1.000000
    

Dropping 'wheelbase' because 'carlength' is more strongly correlated with 'price' than 'wheelbase'


```python
df.drop(columns=['wheelbase'], inplace=True)
```

Dropping Highly Correlated Features to Avoid Redundancy

Dropping 'carwidth' and 'curbweight'  as we already dropped 'wheelbase'


```python
df.drop(columns=['carwidth', 'curbweight'], inplace=True)
```

Dropping 'highwaympg'


```python
df.drop(columns=['highwaympg'], inplace=True)
```

Dropping 'car_stability' to avoid redundancy


```python
df.drop(columns=['car_stability'], inplace=True)
```


```python
df.to_csv('updated_df.csv',index=False)
```

Data Analysis


```python
import matplotlib.pyplot as plt

df.hist(figsize=(12, 8), bins=20, edgecolor='black')
plt.suptitle("Feature Distributions", fontsize=14)
plt.tight_layout() 
plt.show()
```


    
![png](output_104_0.png)
    



```python
brand_columns = [col for col in df.columns if col.startswith('is_')]
print(brand_columns)
```

    ['is_audi', 'is_bmw', 'is_buick', 'is_chevrolet', 'is_dodge', 'is_honda', 'is_isuzu', 'is_jaguar', 'is_mazda', 'is_mercury', 'is_mitsubishi', 'is_nissan', 'is_peugeot', 'is_plymouth', 'is_porsche', 'is_renault', 'is_saab', 'is_subaru', 'is_toyota', 'is_volkswagen', 'is_volvo', 'is_dohcv', 'is_ohc', 'is_ohcf', 'is_ohcv', 'is_rotor', 'is_hardtop', 'is_hatchback', 'is_sedan', 'is_wagon']
    


```python
df['carCompany'] = df[brand_columns].idxmax(axis=1).str.replace("is_", "")
```


```python
print(df[['carCompany']].head())
```

       carCompany
    0      subaru
    1   chevrolet
    2       mazda
    3      toyota
    4  mitsubishi
    


```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>symboling</th>
      <th>CarName</th>
      <th>drivewheel</th>
      <th>carlength</th>
      <th>carheight</th>
      <th>cylindernumber</th>
      <th>enginesize</th>
      <th>fuelsystem</th>
      <th>boreratio</th>
      <th>compressionratio</th>
      <th>...</th>
      <th>enginetype_l</th>
      <th>is_ohc</th>
      <th>is_ohcf</th>
      <th>is_ohcv</th>
      <th>is_rotor</th>
      <th>is_hardtop</th>
      <th>is_hatchback</th>
      <th>is_sedan</th>
      <th>is_wagon</th>
      <th>carCompany</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2</td>
      <td>subaru</td>
      <td>fwd</td>
      <td>156.9</td>
      <td>53.7</td>
      <td>four</td>
      <td>97</td>
      <td>2bbl</td>
      <td>3.62</td>
      <td>9.0</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>subaru</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>chevrolet impala</td>
      <td>fwd</td>
      <td>141.1</td>
      <td>53.2</td>
      <td>three</td>
      <td>61</td>
      <td>2bbl</td>
      <td>2.91</td>
      <td>9.5</td>
      <td>...</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>chevrolet</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>maxda rx3</td>
      <td>fwd</td>
      <td>159.1</td>
      <td>54.1</td>
      <td>four</td>
      <td>91</td>
      <td>2bbl</td>
      <td>3.03</td>
      <td>9.0</td>
      <td>...</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>mazda</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>toyota corona mark ii</td>
      <td>fwd</td>
      <td>158.7</td>
      <td>54.5</td>
      <td>four</td>
      <td>92</td>
      <td>2bbl</td>
      <td>3.05</td>
      <td>9.0</td>
      <td>...</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>toyota</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2</td>
      <td>mitsubishi mirage</td>
      <td>fwd</td>
      <td>157.3</td>
      <td>50.8</td>
      <td>four</td>
      <td>92</td>
      <td>2bbl</td>
      <td>2.97</td>
      <td>9.4</td>
      <td>...</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>mitsubishi</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>200</th>
      <td>0</td>
      <td>bmw x3</td>
      <td>rwd</td>
      <td>197.0</td>
      <td>56.3</td>
      <td>six</td>
      <td>209</td>
      <td>mpfi</td>
      <td>3.62</td>
      <td>8.0</td>
      <td>...</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>bmw</td>
    </tr>
    <tr>
      <th>201</th>
      <td>3</td>
      <td>porsche boxter</td>
      <td>rwd</td>
      <td>168.9</td>
      <td>51.6</td>
      <td>six</td>
      <td>194</td>
      <td>mpfi</td>
      <td>3.74</td>
      <td>9.5</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>porsche</td>
    </tr>
    <tr>
      <th>202</th>
      <td>0</td>
      <td>buick century special</td>
      <td>rwd</td>
      <td>208.1</td>
      <td>56.7</td>
      <td>eight</td>
      <td>308</td>
      <td>mpfi</td>
      <td>3.80</td>
      <td>8.0</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>buick</td>
    </tr>
    <tr>
      <th>203</th>
      <td>0</td>
      <td>bmw x5</td>
      <td>rwd</td>
      <td>193.8</td>
      <td>53.7</td>
      <td>six</td>
      <td>209</td>
      <td>mpfi</td>
      <td>3.62</td>
      <td>8.0</td>
      <td>...</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>bmw</td>
    </tr>
    <tr>
      <th>204</th>
      <td>1</td>
      <td>buick regal sport coupe (turbo)</td>
      <td>rwd</td>
      <td>199.2</td>
      <td>55.4</td>
      <td>eight</td>
      <td>304</td>
      <td>mpfi</td>
      <td>3.80</td>
      <td>8.0</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>buick</td>
    </tr>
  </tbody>
</table>
<p>205 rows × 46 columns</p>
</div>




```python
df.to_csv("updated_df.csv",index=False)
```


```python
df = df.rename(columns={'enginetype_l': 'is_inline'})
```


```python
brand_columns = [col for col in df.columns if col.startswith('is_') and col not in ['is_dohcv', 'is_inline', 'is_ohc', 'is_ohcf', 'is_ohcv', 'is_rotor', 'is_hardtop', 'is_sedan', 'is_hatchback', 'is_wagon']]
print("Car Brand Columns:", brand_columns) 
```

    Car Brand Columns: ['is_audi', 'is_bmw', 'is_buick', 'is_chevrolet', 'is_dodge', 'is_honda', 'is_isuzu', 'is_jaguar', 'is_mazda', 'is_mercury', 'is_mitsubishi', 'is_nissan', 'is_peugeot', 'is_plymouth', 'is_porsche', 'is_renault', 'is_saab', 'is_subaru', 'is_toyota', 'is_volkswagen', 'is_volvo']
    


```python
df['carCompany'] = df[brand_columns].idxmax(axis=1).str.replace("is_", "")
```


```python
print(df[['carCompany', 'is_dohcv', 'is_sedan']].head())
```

       carCompany  is_dohcv  is_sedan
    0      subaru     False     False
    1   chevrolet     False     False
    2       mazda     False     False
    3      toyota     False     False
    4  mitsubishi     False     False
    


```python
df.to_csv("updated_df.csv",index=False)
```


```python
import seaborn as sns
import matplotlib.pyplot as plt

plt.figure(figsize=(12,6))
sns.countplot(x=df['carCompany'], order=df['carCompany'].value_counts().index, palette="viridis")
plt.xticks(rotation=90)
plt.title("Car Brand Distribution")
plt.show()
```

    C:\Users\amogh\AppData\Local\Temp\ipykernel_3952\2154864462.py:5: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      sns.countplot(x=df['carCompany'], order=df['carCompany'].value_counts().index, palette="viridis")
    


    
![png](output_115_1.png)
    



```python
carbody_columns = [col for col in df.columns if col.startswith('is_') and col in ['is_hardtop', 'is_sedan', 'is_hatchback', 'is_wagon']]
print("Car Body Columns:", carbody_columns)
```

    Car Body Columns: ['is_hardtop', 'is_hatchback', 'is_sedan', 'is_wagon']
    


```python
df['carbody'] = df[carbody_columns].idxmax(axis=1).str.replace("is_", "")
```


```python
import seaborn as sns
import matplotlib.pyplot as plt

plt.figure(figsize=(10,6))
sns.barplot(x=df['carbody'], y=df['price'], estimator=sum, palette="coolwarm")
plt.title("Total Price Distribution by Car Body Style")
plt.show()
```

    C:\Users\amogh\AppData\Local\Temp\ipykernel_3952\227401964.py:5: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      sns.barplot(x=df['carbody'], y=df['price'], estimator=sum, palette="coolwarm")
    


    
![png](output_118_1.png)
    



```python
import seaborn as sns
import matplotlib.pyplot as plt

df_numeric = df.select_dtypes(include=['number']) 

plt.figure(figsize=(10,6))
sns.heatmap(df_numeric.corr(), annot=True, cmap="coolwarm")
plt.title("Feature Correlation Heatmap")
plt.show()
```


    
![png](output_119_0.png)
    



```python
plt.figure(figsize=(10,6))
sns.scatterplot(x=df['enginesize'], y=df['price'], hue=df['horsepower'], palette="coolwarm")
plt.title("Engine Size vs Price (Gradient by Horsepower)")
plt.show()
```


    
![png](output_120_0.png)
    



```python
df.to_csv("updated_df.csv",index=False)
```

Insight

From the above graphical representation, based on the Bar Chart, my insight is that 'Toyota' is the most sold car brand, while 'Mercury' is the least sold 

Based on the 'carbody' vs. 'price' analysis, my insight is that sedan and hatchback cars are sold more frequently than wagons and hardtops

From the heatmap analysis, it's clear that engine size and horsepower are closely linked to higher car prices, meaning bigger and more powerful cars tend to cost more. On the other hand, fuel-efficient cars (higher MPG) are generally priced lower, showing a trade-off between performance and efficiency

From the scatter plot, we can see that cars with larger engine sizes generally have higher prices. Additionally, the gradient indicates that cars with higher horsepower also tend to be more expensive, suggesting that both engine size and power significantly impact a car's value

Key Insights

Most sold car brand: Toyota

Least sold car brand: Mercury

Most sold car body type: Sedan

Least sold car body type: Hardtop

Heatmap is very useful for identifying correlations

Cars with bigger engines and higher horsepower tend to have higher prices, and vice versa.

Thank You

Converting CSV to Excel


```python
!pip install openpyxl
```

    Collecting openpyxl
      Downloading openpyxl-3.1.5-py2.py3-none-any.whl.metadata (2.5 kB)
    Collecting et-xmlfile (from openpyxl)
      Downloading et_xmlfile-2.0.0-py3-none-any.whl.metadata (2.7 kB)
    Downloading openpyxl-3.1.5-py2.py3-none-any.whl (250 kB)
       ---------------------------------------- 0.0/250.9 kB ? eta -:--:--
       ---- ----------------------------------- 30.7/250.9 kB 1.4 MB/s eta 0:00:01
       --------- ----------------------------- 61.4/250.9 kB 825.8 kB/s eta 0:00:01
       -------------- ------------------------ 92.2/250.9 kB 871.5 kB/s eta 0:00:01
       ------------------------ --------------- 153.6/250.9 kB 1.0 MB/s eta 0:00:01
       -------------------------------- ------- 204.8/250.9 kB 1.0 MB/s eta 0:00:01
       ---------------------------------------- 250.9/250.9 kB 1.0 MB/s eta 0:00:00
    Downloading et_xmlfile-2.0.0-py3-none-any.whl (18 kB)
    Installing collected packages: et-xmlfile, openpyxl
    Successfully installed et-xmlfile-2.0.0 openpyxl-3.1.5
    

    
    [notice] A new release of pip is available: 24.1.1 -> 25.0.1
    [notice] To update, run: python.exe -m pip install --upgrade pip
    


```python
import pandas as pd
df = pd.read_csv("updated_df.csv") 
df.to_excel("updated_df.xlsx", index=False) 
```

Thank you


```python

```
